import { Injectable } from '@angular/core';
import { map, switchMap } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

/* use those apis to get user geolocations and nationality all apis accept get request
https://backofficeapi.online-tkt.com/api/GetAllCountriesByLangName?LangCode=en
returns all countries with country codes
*********
https://api.ipify.org/?format=json
returns users ip adress
*********
use ip adress to get user geo location and country
https://ipapi.co/${ip-adress}/json/
*/

@Injectable({
  providedIn: 'root'
})
export class MyApisService {
  ip:any='';
  private data= new Subject<string>();
  method$: Observable <any>;
  
  constructor(private http:HttpClient) {
this.method$= this.data.asObservable();
   }
   Mymethod(message:string ){
 
   this.data.next(message);
   }
   getData(){
     let url="https://backofficeapi.online-tkt.com/api/GetAllCountriesByLangName?LangCode=en";
     return this.http.get(url);
   }
   getIpaddress(){
     let ipurl="https://api.ipify.org/?format=json";
     return this.http.get(ipurl);
   }

   getcountry(){
    this.ip=this.http.get('https://api.ipify.org/?format=json')
.pipe(
  switchMap((value:any) => {
	let url='https://ipapi.co/?ip=${value.ip}/json/'
	
   
	return this.http.get(url);
  }))
  .subscribe(
  (value:any) => {
	console.log(value);
  },
  err => {
	console.log(err);
  }
);
    }
    getTest(){
     let url= "https://ipapi.co/${ip}/json/"
     return this.http.get(url);
    }
}
