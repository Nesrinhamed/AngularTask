import { Component, OnInit } from '@angular/core';
import { MyApisService } from 'src/app/services/my-apis.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})

export class WelcomeComponent implements OnInit {
user:string;
  constructor(private service:MyApisService) {
    this.service.method$.subscribe((message)=>{
      this.user=message;
    console.log(this.user);
    });
    
   }

  ngOnInit(): void {
  
  }
  

}
