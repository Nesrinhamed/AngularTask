import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MyApisService } from 'src/app/services/my-apis.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent   {
  ipAddress = '';
  country:any='';
  unamePattern = '[a-zA-Z]*';
  submit: boolean = false;
  usernamee:any='';
  SignUP = new FormGroup({
   
    username: new FormControl('',[Validators.required,Validators.pattern(this.unamePattern)]),
    nationality: new FormControl('', Validators.required),
    email: new FormControl('',Validators.required),
    password: new FormControl('',[Validators.minLength(8), Validators.pattern(this.unamePattern)]),
    passwordconfirmation: new FormControl('',Validators.required),
    ipAddress: new FormControl('',Validators.required),
  });
 
  get username(){
    this.usernamee=this.SignUP.get('username');
    return this.SignUP.get('username');
  }
  get password(){
    return this.SignUP.get('password');
  }
  get confirmpw(){
    if (this.SignUP.get('password').value == this.SignUP.get('passwordconfirmation').value)
     return true;
  }

  constructor(private service:MyApisService,private http:HttpClient,private route:Router) { 
    
    this.service.getData().subscribe(data=>{

      console.log(data);
    })

    this.service.getIpaddress().subscribe((res:any)=>{
      this.ipAddress=res.ip;
           console.log("ip",res.ip);
           let url='https://ipapi.co/'
           let urll=url+res.ip+"/json/";
           console.log('urrrrl',urll);
           this.http.get(urll).subscribe((value:any)=>{
             this.country=value.country_name;
              console.log("country",value.country_name)
           });
           
    })
    
   //this.service.getTest().subscribe((response:any)=>{
//console.log("test",response);
   //})

 }
 
 clicked(){
  this.submit=true;
  this.route.navigate(['welcome']);
  this.service.Mymethod(this.SignUP.get('username').value)
 }

 

  
 
  
}
